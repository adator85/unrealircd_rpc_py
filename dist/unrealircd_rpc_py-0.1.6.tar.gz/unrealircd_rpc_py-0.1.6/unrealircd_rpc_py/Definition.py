from dataclasses import dataclass

@dataclass
class LogTls:
    certfp: str
    cipher: str

@dataclass
class LogUser:
    username: str
    realname: str
    vhost: str
    cloakedhost: str
    servername: str
    reputation: int
    security_groups: list
    modes: str
    channels: list

@dataclass
class LogUser:
    username: str
    realname: str
    vhost: str
    cloakedhost: str
    servername: str
    reputation: int
    security_groups: list
    modes: str
    channels: list

@dataclass
class LogClient:
    name: str
    id: str
    hostname: str
    ip: str
    details: str
    server_port: int
    client_port: int
    connected_since: str
    idle_since: str
    user = LogUser
    tls: LogTls

@dataclass
class LogConnect:
    timestamp: str
    level: str
    subsystem: str
    event_id: str
    log_source: str
    msg: str
    client: LogClient
    extended_client_info: str
    reason: str
    connected_time: int
