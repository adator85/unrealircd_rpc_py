# unrealircd_rpc_py/__init__.py
from .Rpc import Rpc